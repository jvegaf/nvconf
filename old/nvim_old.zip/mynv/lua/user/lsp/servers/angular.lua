require'lspconfig'.angularls.setup{}
