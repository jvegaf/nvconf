local M = {}

M.settings = {}

return M
