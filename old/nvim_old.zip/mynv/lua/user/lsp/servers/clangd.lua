return { capabilities = { offsetEncoding = "utf-8" } }
