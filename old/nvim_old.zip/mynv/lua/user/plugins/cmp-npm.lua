require('cmp-npm').setup({
  ignore = {},
  only_semantic_versions = true,
})

