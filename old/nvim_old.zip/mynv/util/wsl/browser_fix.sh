#!/bin/bash

#          ╭──────────────────────────────────────────────────────────╮
#          │         https://github.com/4U6U57/wsl-open               │
#          ╰──────────────────────────────────────────────────────────╯

npm i -g wsl-open

# Associate wsl-open with links (set wsl-open as your shell's BROWSER)
wsl-open -w

echo "Browser fixed "
